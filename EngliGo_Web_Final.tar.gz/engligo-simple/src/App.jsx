import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [appState, setAppState] = useState('splash');

  useEffect(() => {
    // محاكاة شاشة البداية
    const timer = setTimeout(() => {
      setAppState('levels');
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  if (appState === 'splash') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center">
        <div className="text-center text-white animate-fade-in">
          <div className="text-8xl mb-4 animate-bounce">🗣️</div>
          <h1 className="text-6xl font-bold mb-4 animate-slide-up">EngliGo</h1>
          <p className="text-xl animate-slide-up animation-delay-200">تعلم الإنجليزية بسهولة</p>
          <div className="mt-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xl">🗣️</span>
              </div>
              <h1 className="text-2xl font-bold text-gray-900">المستويات</h1>
            </div>
            <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
              <span className="text-gray-600">👤</span>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Card */}
        <div className="bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg p-6 mb-8 animate-fade-in">
          <h2 className="text-3xl font-bold mb-2">مرحباً بك في EngliGo!</h2>
          <p className="text-lg opacity-90">
            ابدأ رحلتك في تعلم اللغة الإنجليزية من خلال المستويات التفاعلية
          </p>
        </div>

        {/* Levels Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {[
            { id: 1, name: 'Beginner', nameArabic: 'مبتدئ', color: 'from-green-400 to-green-600', unlocked: true },
            { id: 2, name: 'Intermediate', nameArabic: 'متوسط', color: 'from-blue-400 to-blue-600', unlocked: false },
            { id: 3, name: 'Advanced', nameArabic: 'متقدم', color: 'from-purple-400 to-purple-600', unlocked: false }
          ].map((level, index) => (
            <div 
              key={level.id} 
              className={`bg-white rounded-lg shadow-lg overflow-hidden transform transition-all duration-300 hover:scale-105 animate-slide-up`}
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <div className={`h-2 bg-gradient-to-r ${level.color}`}></div>
              
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{level.name}</h3>
                    <p className="text-lg text-gray-600">{level.nameArabic}</p>
                  </div>
                  <div className="text-3xl">
                    {level.unlocked ? '✅' : '🔒'}
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-700">التقدم</span>
                    <span className="text-sm text-gray-500">{level.unlocked ? '100%' : '0%'}</span>
                  </div>
                  <div className="bg-gray-200 rounded-full h-3">
                    <div 
                      className={`bg-gradient-to-r ${level.color} h-3 rounded-full transition-all duration-500`}
                      style={{ width: level.unlocked ? '100%' : '0%' }}
                    ></div>
                  </div>
                </div>

                <div className="flex justify-between text-sm text-gray-600 mb-4">
                  <div className="text-center">
                    <div className="font-semibold">4</div>
                    <div>الدروس</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold">4</div>
                    <div>الاختبارات</div>
                  </div>
                </div>

                <button 
                  className={`w-full py-3 px-4 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 ${
                    level.unlocked 
                      ? 'bg-green-500 text-white hover:bg-green-600 shadow-lg hover:shadow-xl' 
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                  disabled={!level.unlocked}
                >
                  {level.unlocked ? 'ابدأ التعلم' : 'مقفل'}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Ad Banner Placeholder */}
        <div className="bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg p-6 mb-8 animate-fade-in animation-delay-600">
          <div className="text-center">
            <div className="text-gray-500 text-sm mb-2">إعلان تجريبي</div>
            <div className="bg-gradient-to-r from-blue-400 to-purple-500 text-white p-4 rounded-lg">
              <h3 className="font-bold text-lg mb-2">تعلم المزيد مع EngliGo Pro!</h3>
              <p className="text-sm">احصل على دروس إضافية ومميزات حصرية</p>
              <button className="mt-2 bg-white text-blue-600 px-4 py-2 rounded-full text-sm font-semibold hover:bg-gray-100 transition-colors">
                اشترك الآن
              </button>
            </div>
          </div>
        </div>

        {/* Tips Card */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-6 animate-fade-in animation-delay-800">
          <h3 className="text-green-800 font-bold text-lg mb-2 flex items-center">
            <span className="mr-2">💡</span>
            نصائح للتعلم
          </h3>
          <ul className="text-green-700 space-y-2">
            <li>• أكمل جميع الدروس قبل الانتقال للاختبار</li>
            <li>• احصل على 70% أو أكثر لفتح المستوى التالي</li>
            <li>• يمكنك إعادة الاختبارات لتحسين نتيجتك</li>
          </ul>
        </div>
      </main>
    </div>
  );
}

export default App;
